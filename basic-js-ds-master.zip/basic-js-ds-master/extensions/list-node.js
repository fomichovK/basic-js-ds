class ListNode {
  constructor(x) {
    this.value = x;
    this.next = null;
  }
}

module.exports = {
  ListNode
};
